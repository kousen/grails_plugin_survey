class SeleniumTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
